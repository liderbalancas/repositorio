#include <iostream>
#include <Windows.h>

/*Tidos de funções*/
typedef bool  (*Serial)         (char*porta,int baudeRate);
typedef bool  (*Tcp)            (char*host,int porta);
typedef char* (*Peso)           ();
typedef int   (*Status)         ();
typedef bool  (*IsOpen)         ();
typedef void  (*Wait)           ();
typedef bool  (*Close)          ();

/*Funções: tarar, tararManual e zerar são apartir da versão do Indicador A8 check a versão do seu produto*/
typedef int   (*Tara)           ();
typedef int   (*TaraManual)     (int peso);
typedef bool  (*Zera)           ();


int main(int argc, char *argv[])
{
#ifdef WIN32
    //Carrega a API Indicador.dll
    HINSTANCE indicador = LoadLibrary(L"C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll");

    //checa se o indicador foi carregado com sucesso
    if(indicador)
    {
        //Função openSerial
        Tcp openTcp = (Tcp) GetProcAddress(indicador,"openTcp");
        Serial openSerial = (Serial) GetProcAddress(indicador,"openSerial");

        //abre a porta
        bool statusSerial = openSerial("COM4",9600);

        /*Função Tcp exemplo

        Tcp openTcp = (Tcp) GetProcAddress(indicador,"openTcp");

        //abre comunicação via rede
        bool estaAbertaTcp = openTcp("192.168.0.201",3500); exemplo

        */

        //checa o status da porta aberta = true or fechada = false
        if(statusSerial)
        {
            //Chama as funções da API
            Peso peso              = (Peso) GetProcAddress(indicador,"getPeso");
            Peso tara              = (Peso) GetProcAddress(indicador,"getTara");
            Peso pesoBruto         = (Peso) GetProcAddress(indicador,"getPesoBruto");
            Status status          = (Status) GetProcAddress(indicador,"getStatus");
            IsOpen isOpen          = (IsOpen) GetProcAddress(indicador,"isOpen");
            Close close            = (Close) GetProcAddress(indicador,"close");
            Wait wait              = (Wait) GetProcAddress(indicador,"waiting");
			Tara tarar             = (Tara) GetProcAddress(indicador,"tarar");
			TaraManual tararManual = (TaraManual) GetProcAddress(indicador,"tararManual");
			Zera zerar             = (Zera) GetProcAddress(indicador,"zerar");

            //Loop checando se a conexão está aberta, para sair do loop chama a função close()
            while(isOpen())
            {
                std::cout << "PesoBruto: " << pesoBruto() << " Peso Liquido: " << peso() << " Tara: " << tara() << " Status: " << status() << std::endl;

                /* Função wait()
                 * Espera a transação do buffer está pronta para leitura.
                 * Obs. Essa função é apenas usada dentro de um loop
                */
                wait();
            }

            //fecha a conexao
            close();

            //descarrega a dll na memoria
            FreeLibrary(indicador);

        }// fim do statement


    }// fim do statement if

#endif
    return 0;
}
