﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Lider
{
    /**Exemplo de codigo C# para chamar a API Indicador.dll*/
       
    class Program
    {
         //Caminho da Dll
         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll", CallingConvention = CallingConvention.Cdecl)]
         public static extern bool openSerial(string porta, int baudeRate); // metedo abrir comunicação com a porta serial

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll", CallingConvention = CallingConvention.Cdecl)]
         public static extern bool openTcp(string host, int porta); // metedo abrir comunicação Tcp

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern bool isOpen(); // checa se a conexão está aberta 

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern IntPtr getPeso(); // obtem o peso liquido da balanca

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern IntPtr getTara(); // obtem a tara do indicador

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern IntPtr getPesoBruto(); // obtem o peso bruto da balança
                
         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern bool close(); // fecha a conexão serial porta ou tcp

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern int getStatus(); // fecha a conexão serial porta ou tcp

         [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern void waiting(); // espara para leitura (usa essa função dentro de um loop)

		 /*Funções: tarar, tararManual e zerar são apartir da versão do Indicador A8 check a versão do seu produto*/
		 [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
         public static extern bool zerar(); // Indicador executa a função zerar
		 
		 [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
		 public static extern int tarar(); // Indicador executa a função tara se balanca estiver com peso
		 
		 [DllImport("C:\\Users\\Everton\\Documents\\Indicador-dev-2\\lib\\Indicador.dll")]
		 public static extern int tararManual(int peso); // Indicador executa a função tara manual passando parametro desejado da tara se a balança estiver zerada

     static void Main()
        {              
            bool estaAbertaSerial = openSerial("COM4",9600); //exemplo
          //bool estaAbertaTcp    = openTcp("192.168.0.201",3500); exemplo

          //checa se a a porta foi aberta com sucesso
            if (estaAbertaSerial)
            {
                //Variaveis
                String peso;
                String tara;
                String pesoBruto;
                int status;

                //Loop checando se a conexão está aberta, para sair do loop chama a função close()    
                while (isOpen())
                {
                    //Converte Ponteiro para tipo String
                    IntPtr pesoString = getPeso();
                    peso = Marshal.PtrToStringAnsi(pesoString);

                    //Converte Ponteiro para tipo String
                    IntPtr taraString = getTara();
                    tara = Marshal.PtrToStringAnsi(taraString);

                    //Converte Ponteiro para tipo String
                    IntPtr pesoBrutoString = getPesoBruto();
                    pesoBruto = Marshal.PtrToStringAnsi(pesoBrutoString);

                    //obtem o status da balança
                    status = getStatus();

                    //OutStream Saida para console
                    Console.WriteLine("Peso Bruto: "+pesoBruto+" Peso Liquido: "+peso +" Tara: "+ tara + " Status: "+status);

                    /* Função waiting()
                     * Espera a transação do buffer está pronta para leitura. 
                     * Obs. Essa função é apenas usada dentro de um loop
                    */
                    waiting();

                }// fim do statement while


            }// fim do statement if
             
                      
        }


    }
}
