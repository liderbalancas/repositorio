#ifndef INDICADOR_H
#define INDICADOR_H

/*
 Autor: Everton Fonseca
 Biblioteca: Indicador
 Empresa: Lider Balanças
 Departamento: Engenharia
 Monitor: Fernando
 Data: 26/08/2016
 Revisão: 20/03/2017
 Versão: 1.1
 Descrição: Essa biblioteca é responsavel por obter todas as informações do indicador
 quando estever conectado via porta serial ou mesmo na rede tcp

              Funções:
 getPeso      = Obtem o peso liquido da balança
 getTara      = Obtem o peso da tara
 getPesoBruto = Obtem o peso bruto da balança (Liquido + Tara)
 getStatus    = Obtem o tipo de status no momento da pesagem (Estavel,Instavel,Pico,Medio,Imprimir)
 waiting      = espera para ficar pronto o tempo do buffer para ser lido na transmissão
 isOpen       = checa se a comunicação da serial ou tcp está aberta retorna true ou false

              Funções: apartir do indicador da versão A8:
  tarar       = tara o peso da balança
  tararManual = define o valor da tara se a balança estiver com peso 0
  zerar       = zero a balança
*/

#include <string.h>
#include "serial.h"
#include "tcp.h"
#include "QtCore/QThread"
#include "QtCore/QObject"
#include "QtCore/qcompilerdetection.h"
#include "QtCore/QCoreApplication"
#include "QtCore/QFile"
#include "QtCore/QDir"
#include "QtCore/QLibrary"

namespace IndicadorSerial {   class Serial; }
namespace IndicadorTcp    {   class Tcp;    }

class Q_DECL_EXPORT Indicador : public QObject
{
public:

    friend class ProtocoloLider;
    friend class ThreadLider;
    friend class ProtocoloPeso;
    friend class IndicadorSerial::Serial;
    friend class IndicadorTcp::Tcp;

    /*
    Status do Peso valores constante

    NULO     = -1
    Estavel  =  0
    Instavel =  1
    Pico     =  2
    Medio    =  3
    Imprimir =  4

    */
    enum Status{Null= -1,Estavel = 0,Instavel = 1,Pico = 2,Medio = 3,Imprimir = 4};

    explicit Indicador();
    virtual  ~Indicador();

    //Funcões
    inline virtual Status getStatus();// obtem o statu do peso da balança conforme protocolo Estavel, Instavel,Pico ou Medio
    inline virtual char* getPeso(); // obtem o Peso Liquido da balanca
    inline virtual char* getTara(); // obtem o Peso da Tara da balanca
    inline virtual char* getPesoBruto(); // obtem o Peso Bruto da balanca
    virtual bool  isOpen();  // cheque se a conexão da serial ou mesmo tcp está aberta
    virtual bool  openSerial(char *portaName,int baudeRate); // inicia a transmissão com o indicador na serial
    virtual bool  openTcp(char *host,int porta); // inicia a transmissão com o indicador na rede TCP

    //Estar funções apenas funciona apartir das versao A8 do indicador
    virtual bool  zerar(); // chama a função zerar do indicador retorna true ou false como sucesso

    /*
     * Estar funções apenas funciona apartir das versao A8 do indicador
     Função: tarar
     descrição: chama a função tara  do indicador
     retorno: tipo dado = inteiro
      0 = (TARA SEMI AUTOMATICA OK)
      1 = (LIMPESA MANUAL DE TARA)
      2 = (SE TARA SUCESSIVA OK)
      3 = (LIMPA VALOR DA TARA Tara = 0)
      4 = (TARA MANUAL ON)
     -1 = (ERRO TARA ENVIADA OU PESO SOBRE A CELULA > CAPACIDADE)
     -2 = (ERRO TEM TARA ATIVA)
     -3 = (ERRO TARA AUTOMATICA ESTA ON)
     -4 = (ERRO PESO > 0 NÃO PODE TARAR)
     -5 = (MODO VALOR DE PICO NÃO TEM TARA)
     -6 = (PESO == O ENVIAR TARA COM VALOR NÃO ENVIAR SOLICITAÇÃO DE TARA!!!)
     -7 = (TARA SUCESSIVA ON, ENVIAR SOLICITAÇÃO DE TARA COMO PESO SOBRE CELULA)
     -8 = (INDICADOR NÃO ESTÁ RESPONDENDO)
    */
    virtual int   tarar();
    /*
     * Estar funções apenas funciona apartir das versao A8 do indicador
     Função: tararManual
     descrição: chama a função tara manual do indicador
     retorno: tipo dado = inteiro
      4 = (TARA MANUAL ON)
     -1 = (ERRO TARA ENVIADA OU PESO SOBRE A CELULA > CAPACIDADE)
     -2 = (ERRO TEM TARA ATIVA)
     -3 = (ERRO TARA AUTOMATICA ESTA ON)
     -4 = (ERRO PESO > 0 NÃO PODE TARAR)
     -5 = (MODO VALOR DE PICO NÃO TEM TARA)
     -6 = (PESO == O ENVIAR TARA COM VALOR NÃO ENVIAR SOLICITAÇÃO DE TARA!!!)
     -7 = (TARA SUCESSIVA ON, ENVIAR SOLICITAÇÃO DE TARA COMO PESO SOBRE CELULA)
     -8 = (INDICADOR NÃO ESTÁ RESPONDENDO)
    */
    virtual int   tararManual(uint32_t peso);
    virtual bool  close(); // para a transmisao do indicador serial ou tcp
    inline virtual void  waiting(); // espera para ficar pronto o tempo do buffer para ser lido na transmissão

private:

    //Variaveis Privadas Não são acessiveis
    char* peso;
    char* tara;
    char* pesoBruto;
    Status statu;
    int codigoProtocolo;

    /****** Metedos privados Não são acessiveis ************/
    void setStatus(Status statu);
    void setPeso(char* peso);
    void setTara(char* tara);
    void setPesoBruto(char* pesoBruto);

protected:
    static QCoreApplication *a;
    QLibrary *libCore;
    QLibrary *libNetwork;
    QLibrary *libSerial;

};

/* Funções externas*/
extern "C" {

Q_DECL_EXPORT bool openSerial(char* porta,int baudeRate);
Q_DECL_EXPORT bool openTcp(char* host,int porta);
Q_DECL_EXPORT char *getPeso();
Q_DECL_EXPORT char *getTara();
Q_DECL_EXPORT char *getPesoBruto();
Q_DECL_EXPORT Indicador::Status getStatus();
Q_DECL_EXPORT bool close();

/*Funções zerar, tarar e tararManual apenas funciona apartir do indicador da versão A8*/
Q_DECL_EXPORT bool zerar();
Q_DECL_EXPORT int  tarar();
Q_DECL_EXPORT int  tararManual(int peso);

Q_DECL_EXPORT bool isOpen();
Q_DECL_EXPORT void waiting();

}

#endif // INDICADOR_H
