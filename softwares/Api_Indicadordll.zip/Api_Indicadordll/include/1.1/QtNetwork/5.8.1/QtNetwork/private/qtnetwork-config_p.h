#define QT_FEATURE_libproxy -1
#define QT_FEATURE_securetransport -1
#define QT_FEATURE_openssl_linked -1
#define QT_FEATURE_openssl -1
#define QT_FEATURE_system_proxies 1
